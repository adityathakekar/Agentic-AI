# Architecture

Sequential Multi-Agent System.